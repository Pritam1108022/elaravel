-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2018 at 07:12 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elaravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_12_02_035528_create_tbl_admin_table', 1),
(2, '2018_12_02_151355_create_tbl_category_table', 2),
(3, '2018_12_04_053646_create_manufacture_table', 3),
(4, '2018_12_05_044050_create_tbl_products_table', 4),
(5, '2018_12_06_080312_create_tbl_slider_table', 5),
(6, '2018_12_06_081056_create_tbl_slider_table', 6),
(7, '2018_12_08_060622_create_tbl_customer_table', 7),
(8, '2018_12_08_080212_create_tbl_shipping_table', 8),
(9, '2018_12_15_085517_create_tbl_payment_table', 9),
(10, '2018_12_15_085632_create_tbl_order_table', 9),
(11, '2018_12_15_085704_create_tbl_order_details_table', 9);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `admin_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_email`, `admin_password`, `admin_name`, `admin_phone`, `created_at`, `updated_at`) VALUES
(1, 'pritamghoshcse22@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Pritam Ghosh', '01758125411', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `category_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`, `category_description`, `publication_status`, `created_at`, `updated_at`) VALUES
(1, 'Men', 'This is men category', 1, NULL, NULL),
(2, 'Women', 'This is women category.', 0, NULL, NULL),
(3, 'Child', 'This is child category', 1, NULL, NULL),
(5, 'Sport', 'This is sport category', 1, NULL, NULL),
(6, 'Boy', 'This is boy category', 1, NULL, NULL),
(8, 'Cloth', 'This is cloth category', 1, NULL, NULL),
(9, 'Furniture', 'THis is furniture category', 1, NULL, NULL),
(10, 'Shoe', 'This is shoe category', 0, NULL, NULL),
(11, 'bags', 'This is bag category', NULL, NULL, NULL),
(12, 'Book', 'This is book category&nbsp;', 1, NULL, NULL),
(13, 'Mobile', 'Mobile category', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `customer_id` int(10) UNSIGNED NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customer_id`, `customer_name`, `customer_email`, `password`, `mobile_number`, `created_at`, `updated_at`) VALUES
(3, 'Osman', 'osamn@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01987652345', NULL, NULL),
(4, 'Pritam', 'pritamghoshcse22@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01758125411', NULL, NULL),
(5, 'riaz', 'riaz@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '11111', NULL, NULL),
(6, 'paLASH', 'paLASH@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '33333', NULL, NULL),
(7, 'Rima Das', 'rima@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '0189999999', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_manufacture`
--

CREATE TABLE `tbl_manufacture` (
  `manufacture_id` int(10) UNSIGNED NOT NULL,
  `manufacture_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacture_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_manufacture`
--

INSERT INTO `tbl_manufacture` (`manufacture_id`, `manufacture_name`, `manufacture_description`, `publication_status`, `created_at`, `updated_at`) VALUES
(1, 'Samsung', 'This is samsung brands.', 0, NULL, NULL),
(4, 'cats eye', 'cats eye is on.', 1, NULL, NULL),
(5, 'Apple', 'Apple brands', 1, NULL, NULL),
(6, 'Anondo Prokashoni', 'Its a book store.', 1, NULL, NULL),
(7, 'Otobi', 'It a furniture store', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `order_total` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `customer_id`, `shipping_id`, `payment_id`, `order_total`, `order_status`, `created_at`, `updated_at`) VALUES
(1, 1, 9, 4, '60,000.00', 'pending', '2018-12-15 13:22:34', NULL),
(2, 1, 10, 5, '60,000.00', 'pending', '2018-12-15 13:27:11', NULL),
(3, 1, 11, 6, '60,000.00', 'pending', '2018-12-15 15:22:37', NULL),
(4, 1, 11, 7, '60,000.00', 'pending', '2018-12-15 15:23:10', NULL),
(5, 1, 11, 8, '60,000.00', 'pending', '2018-12-15 15:27:00', NULL),
(6, 3, 12, 9, '140,000.00', 'pending', '2018-12-15 17:28:40', NULL),
(7, 4, 13, 10, '60,000.00', 'pending', '2018-12-15 17:34:42', NULL),
(8, 5, 14, 11, '200,000.00', 'pending', '2018-12-15 18:14:59', NULL),
(9, 6, 15, 12, '120,000.00', 'pending', '2018-12-15 18:21:08', NULL),
(10, 7, 16, 13, '4,000.00', 'pending', '2018-12-16 15:26:26', NULL),
(13, 4, 17, 16, '121,000.00', 'pending', '2018-12-16 16:04:30', NULL),
(14, 4, 18, 17, '3,000.00', 'pending', '2018-12-17 06:02:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `order_details_id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_sales_quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`order_details_id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_sales_quantity`, `created_at`, `updated_at`) VALUES
(1, 2, 7, 'zeans', '60000', '1', NULL, NULL),
(2, 3, 4, 'Iphone 5', '60000', '1', NULL, NULL),
(3, 4, 4, 'Iphone 5', '60000', '1', NULL, NULL),
(4, 5, 4, 'Iphone 5', '60000', '1', NULL, NULL),
(5, 6, 6, 'Iphone 8', '70000', '2', NULL, NULL),
(6, 7, 4, 'Iphone 5', '60000', '1', NULL, NULL),
(7, 8, 4, 'Iphone 5', '60000', '1', NULL, NULL),
(8, 8, 6, 'Iphone 8', '70000', '2', NULL, NULL),
(9, 9, 7, 'zeans', '60000', '1', NULL, NULL),
(10, 9, 4, 'Iphone 5', '60000', '1', NULL, NULL),
(11, 10, 12, 'Panjabi', '2000', '2', NULL, NULL),
(12, 13, 8, 'Jacket', '1000', '1', NULL, NULL),
(13, 13, 4, 'Iphone 5', '60000', '2', NULL, NULL),
(14, 14, 8, 'Jacket', '1000', '3', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `payment_id` int(10) UNSIGNED NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`payment_id`, `payment_method`, `payment_status`, `created_at`, `updated_at`) VALUES
(1, 'handcash', 'pending', '2018-12-15 13:11:21', NULL),
(2, 'handcash', 'pending', '2018-12-15 13:14:08', NULL),
(3, 'handcash', 'pending', '2018-12-15 13:17:06', NULL),
(4, 'handcash', 'pending', '2018-12-15 13:22:33', NULL),
(5, 'handcash', 'pending', '2018-12-15 13:27:11', NULL),
(6, 'handcash', 'pending', '2018-12-15 15:22:37', NULL),
(7, 'handcash', 'pending', '2018-12-15 15:23:10', NULL),
(8, 'handcash', 'pending', '2018-12-15 15:27:00', NULL),
(9, 'handcash', 'pending', '2018-12-15 17:28:40', NULL),
(10, 'handcash', 'pending', '2018-12-15 17:34:42', NULL),
(11, 'handcash', 'pending', '2018-12-15 18:14:59', NULL),
(12, 'handcash', 'pending', '2018-12-15 18:21:08', NULL),
(13, 'handcash', 'pending', '2018-12-16 15:26:25', NULL),
(14, 'handcash', 'pending', '2018-12-16 15:27:07', NULL),
(15, 'handcash', 'pending', '2018-12-16 15:27:29', NULL),
(16, 'handcash', 'pending', '2018-12-16 16:04:30', NULL),
(17, 'handcash', 'pending', '2018-12-17 06:02:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `manufacture_id` int(11) NOT NULL,
  `product_short_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_long_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` double(8,2) NOT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`product_id`, `product_name`, `category_id`, `manufacture_id`, `product_short_description`, `product_long_description`, `product_price`, `product_image`, `product_size`, `product_color`, `publication_status`, `created_at`, `updated_at`) VALUES
(4, 'Iphone 5', 13, 5, 'ghfd', 'hfghf', 60000.00, 'image/2uUR8khibQ1b3zugLrVM.jpg', '4.8\' inch', 'Black,gold', 1, NULL, NULL),
(6, 'Iphone 8', 13, 5, 'ddd', 'dasfds', 70000.00, 'image/cBqUzcqHZ4FarDbaBeOy.jpg', '4.8\' inch', 'Black,gold', 1, NULL, NULL),
(8, 'Jacket', 1, 4, '<span style=\"font-size: 13.3333px;\">New jacket</span>', '<span style=\"font-size: 13.3333px;\">Its New stylish jacket</span>', 1000.00, 'image/bRNitPiS2pTu9LYBV42G.jpg', '30\"', 'Black', 1, NULL, NULL),
(9, 'Nine-ten Book', 12, 6, 'grammer book.', '<span style=\"font-size: 13.3333px;\">It a bengali grammer book.</span>', 100.00, 'image/PRGbYkbcn0ufTz3GTXOB.jpg', '5\"', 'white', 1, NULL, NULL),
(10, 'Cricket Bat and Ball', 5, 7, '<span style=\"font-size: 13.3333px;\">bat and ball.</span>', '<span style=\"font-size: 13.3333px;\">Its a cricket bat and ball.</span>', 500.00, 'image/xxZOScfQPnOBSovtosp6.jpg', '10\"', 'White', 1, NULL, NULL),
(11, 'Dinner Set', 9, 7, '<span style=\"font-size: 13.3333px;\">dinner set</span>', '<span style=\"font-size: 13.3333px;\">Its&nbsp; a latest dinner set</span>', 5000.00, 'image/IpN5IwDS99PHrTEXNKuD.jpg', '20\'', 'Black', 1, NULL, NULL),
(12, 'Panjabi', 3, 4, '<span style=\"font-size: 13.3333px;\">dress for child</span>', '<span style=\"font-size: 13.3333px;\">Its a latest dress for child</span>', 2000.00, 'image/iLAEnl3d50B30HwbPiXK.jpeg', '5\"', 'White', 1, NULL, NULL),
(13, 'Long Sleeve Dress', 2, 4, '<span style=\"font-size: 13.3333px;\">&nbsp;women dress</span>', '<span style=\"font-size: 13.3333px;\">Its a women dress</span>', 2000.00, 'image/gpIqOrQ9HEN2XvTSaqUc.jpg', '10\"', 'Black', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping`
--

CREATE TABLE `tbl_shipping` (
  `shipping_id` int(10) UNSIGNED NOT NULL,
  `shipping_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_mobile_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_shipping`
--

INSERT INTO `tbl_shipping` (`shipping_id`, `shipping_email`, `shipping_first_name`, `shipping_last_name`, `shipping_address`, `shipping_mobile_number`, `shipping_city`, `created_at`, `updated_at`) VALUES
(1, 'pritam@gmail.com', 'gff', 'dfgdf', 'sdfg', 'dfsgdf', 'sdfgdf', NULL, NULL),
(2, 'pritam@gmail.com', 'gfd', 'sdfg', 'sdfg', 'dfg', 'dsfg', NULL, NULL),
(3, 'pritam@gmail.com', 'gfd', 'sdfg', 'sdfg', 'dfsgdf', 'sdfgdf', NULL, NULL),
(4, 'pritam@gmail.com', 'gff', 'dfgdf', 'sdfg', 'dfsgdf', 'sdfgdf', NULL, NULL),
(5, 'pritam@gmail.com', 'gff', 'dfgdf', 'sdfg', 'dfsgdf', 'sdfgdf', NULL, NULL),
(6, 'fds@gmail.com', 'dfh', 'fgh', 'fdhgg', 'fgh', 'fdgh', NULL, NULL),
(7, 'fds@gmail.com', 'tret', 'rwet', 'wert', 'ert', 'ert', NULL, NULL),
(8, 'fds@gmail.com', 'dfh', 'rwet', 'wert', 'fgh', 'fdgh', NULL, NULL),
(9, 'fds@gmail.com', 'dfh', 'rwet', 'wert', 'fgh', 'fdgh', NULL, NULL),
(10, 'pritam@gmail.com', 'gff', 'dfgdf', 'sdfg', 'dfsgdf', 'sdfgdf', NULL, NULL),
(11, 'fds@gmail.com', 'dfh', 'rwet', 'wert', 'fgh', 'fdgh', NULL, NULL),
(12, 'fds@gmail.com', 'dfh', 'rwet', 'wert', 'fgh', 'fdgh', NULL, NULL),
(13, 'pritam@gmail.com', 'dfh', 'rwet', 'wert', 'fgh', 'fdgh', NULL, NULL),
(14, 'riaz@gmail.com', 'riaz', 'haq', 'cumilla', '1111', 'cumilla', NULL, NULL),
(15, 'praa@gmail.com', 'gff', 'dfgdf', 'sdfg', 'dfg', 'sdfgdf', NULL, NULL),
(16, 'rima@gmail.com', 'rima', 'das', 'ctg', '0198888', 'ctg', NULL, NULL),
(17, 'pritam@gmail.com', 'pritam', 'ghosh', 'cumilla', '01758125411', 'cumilla', NULL, NULL),
(18, 'pritam@gmail.com', 'dfh', 'rwet', 'wert', 'ert', 'fdgh', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `slider_id` int(10) UNSIGNED NOT NULL,
  `slider_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`slider_id`, `slider_image`, `publication_status`, `created_at`, `updated_at`) VALUES
(3, 'image/3A8B3CZ8GaSErnYxnAMW.jpg', '0', NULL, NULL),
(4, 'image/IQLUvNsUMJEm9OKzo7PO.jpg', '1', NULL, NULL),
(7, 'image/l0gJwKWB9UiTrFG9T6UO.jpg', '1', NULL, NULL),
(8, 'image/jZqRHDkOwgNFWObrLbvp.jpg', '1', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tbl_manufacture`
--
ALTER TABLE `tbl_manufacture`
  ADD PRIMARY KEY (`manufacture_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`order_details_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  ADD PRIMARY KEY (`shipping_id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `category_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_manufacture`
--
ALTER TABLE `tbl_manufacture`
  MODIFY `manufacture_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `order_details_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `payment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  MODIFY `shipping_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `slider_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
